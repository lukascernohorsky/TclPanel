namespace eval ::power {}
proc ::power::popup {button} {
    set m [menu .powermenu -tearoff 0]
    $m add command -label "Log out (window manager dependent)" -command {puts "Configure your WM logout command in config.tcl"}
    $m add command -label "Lock screen" -command {if {[auto_execok xlock] ne ""} {exec xlock &} elseif {[auto_execok xscreensaver-command] ne ""} {exec xscreensaver-command -lock &}}
    tk_popup $m [winfo rootx $button] [expr {[winfo rooty $button]+[winfo height $button]}]
}
