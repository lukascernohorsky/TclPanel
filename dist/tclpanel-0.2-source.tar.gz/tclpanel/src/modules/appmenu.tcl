namespace eval ::appmenu { variable entries {} }
proc ::appmenu::scan {} {
    variable entries; set entries {}
    set dirs {}
    if {[info exists ::env(XDG_DATA_HOME)]} {lappend dirs [file join $::env(XDG_DATA_HOME) applications]} else {lappend dirs [file join $::env(HOME) .local share applications]}
    if {[info exists ::env(XDG_DATA_DIRS)]} {foreach d [split $::env(XDG_DATA_DIRS) :] {lappend dirs [file join $d applications]}} else {lappend dirs /usr/local/share/applications /usr/share/applications}
    foreach dir [lsort -unique $dirs] {
        if {![file isdirectory $dir]} continue
        foreach f [glob -nocomplain -directory $dir *.desktop] {
            set ch [open $f r]; set data [read $ch]; close $ch
            if {![regexp -line {^\[Desktop Entry\]$} $data]} continue
            if {[regexp -line {^Hidden=true$|^NoDisplay=true$} $data]} continue
            set name ""; set exec ""; set cat "Other"
            foreach line [split $data \n] {
                if {[regexp {^Name=([^\r]*)} $line -> v]} {set name $v}
                if {[regexp {^Exec=([^\r]*)} $line -> v]} {set exec $v}
                if {[regexp {^Categories=([^;]+)} $line -> v]} {set cat [lindex [split $v ;] 0]}
            }
            if {$name ne "" && $exec ne "" && ![dict exists $entries $name]} {dict set entries $name [list $exec $f $cat]}
        }
    }
}
proc ::appmenu::expandExec {exec name file} {
    # Desktop Entry field codes: unsupported file/URL arguments are removed.
    set exec [string map [list %% % %c $name %k $file %i "" %f "" %F "" %u "" %U ""] $exec]
    return [string trim $exec]
}
proc ::appmenu::launch {exec name file} {
    set cmd [expandExec $exec $name $file]
    if {[catch {exec sh -c $cmd > /dev/null 2>@1 &} err]} {puts stderr "TclPanel app menu: $err"}
}
proc ::appmenu::popup {button} {
    variable entries; scan
    set m [menu .appmenu -tearoff 0]
    foreach name [lsort -dictionary [dict keys $entries]] {
        lassign [dict get $entries $name] exec file cat
        $m add command -label $name -command [list ::appmenu::launch $exec $name $file]
    }
    tk_popup $m [winfo rootx $button] [expr {[winfo rooty $button]+[winfo height $button]}]
}
