namespace eval ::workspace {}
proc ::workspace::build {w} {
    set count 1; catch {set count [::x11::desktops]}
    set current 0; catch {set current [::x11::desktop]}
    for {set i 0} {$i < $count} {incr i} {
        ttk::button $w.d$i -text [expr {$i+1}] -width 2 -command [list ::x11::setdesktop $i]
        pack $w.d$i -side left -padx 1
    }
}
