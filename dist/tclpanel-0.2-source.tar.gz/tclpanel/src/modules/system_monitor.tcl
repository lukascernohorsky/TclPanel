namespace eval ::sysmon {}
proc ::sysmon::sample {} {
    if {$::tcl_platform(os) eq "FreeBSD"} {
        if {![catch {exec sysctl -n vm.stats.vm.v_free_count} free] && ![catch {exec sysctl -n vm.stats.vm.v_page_count} total] && $total > 0} {return "RAM pages: $free / $total"}
        return "FreeBSD"
    }
    if {[file readable /proc/meminfo]} {
        set f [open /proc/meminfo]; set d [read $f]; close $f
        if {[regexp {MemAvailable:\s+(\d+)} $d -> avail] && [regexp {MemTotal:\s+(\d+)} $d -> total]} {return [format "RAM %d%%" [expr {100-($avail*100/$total)}]]}
    }
    return "System"
}
namespace eval ::system_monitor {}
proc ::system_monitor::shutdown {} {}
