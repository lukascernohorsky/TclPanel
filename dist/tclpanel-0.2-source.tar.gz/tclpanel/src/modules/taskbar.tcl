namespace eval ::taskbar { variable ids {}; variable parent {} }
proc ::taskbar::refresh {w} {
    variable ids
    variable parent
    set parent $w
    if {![winfo exists $w]} return
    foreach child [winfo children $w] {destroy $child}
    set current 0; catch {set current [::x11::desktop]}
    foreach row [::x11::windows] {
        lassign $row id title desk
        if {$title eq ""} {set title $id}
        if {$desk != 4294967295 && $desk != $current} continue
        set short [string range $title 0 27]
        ttk::button $w.b[incr ::taskbar::serial] -text $short -command [list ::taskbar::activate $id]
        pack $w.b$::taskbar::serial -side left -padx 2 -fill y
        bind $w.b$::taskbar::serial <Button-3> [list ::taskbar::minimize $id]
    }
}
set ::taskbar::serial 0
proc ::taskbar::activate {id} {catch {::x11::activate $id}}
proc ::taskbar::minimize {id} {catch {::x11::minimize $id}}

proc ::taskbar::shutdown {} {
    variable parent
    if {$parent ne "" && [winfo exists $parent]} {foreach child [winfo children $parent] {destroy $child}}
}
