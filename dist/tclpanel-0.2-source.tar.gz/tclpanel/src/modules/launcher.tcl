namespace eval ::launcher {}
proc ::launcher::run {cmd} {
    if {[catch {exec sh -c $cmd > /dev/null 2>@1 &} err]} { puts stderr "TclPanel launcher: $err" }
}
proc ::launcher::favorites {parent} {
    foreach app $::cfg(favorites) {
        set label [string totitle $app]
        ttk::button $parent.f[incr ::launcher::n] -text $label -command [list ::launcher::run $app]
        pack $parent.f$::launcher::n -side left -padx 2 -pady 2
    }
}
set ::launcher::n 0
