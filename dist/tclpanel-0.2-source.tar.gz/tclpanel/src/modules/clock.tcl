namespace eval ::clockmod { variable timers }
proc ::clockmod::update {label} {
    variable timers
    if {![winfo exists $label]} return
    $label configure -text [clock format [clock seconds] -format {%H:%M  %d.%m.%Y}]
    set timers($label) [after 1000 [list ::clockmod::update $label]]
}
proc ::clockmod::shutdown {} {
    variable timers
    foreach label [array names timers] {catch {after cancel $timers($label)}}
    array unset timers
}
namespace eval ::clock {}
proc ::clock::shutdown {} {::clockmod::shutdown}
