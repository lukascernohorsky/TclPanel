namespace eval ::tray {}
proc ::tray::start {parent} {
    if {![llength [info commands ::x11::tray_start]]} {return}
    if {![winfo exists $parent]} {ttk::frame $parent -width 100 -height 30}
    pack propagate $parent 0
    bind $parent <Configure> {after idle ::tray::layout}
    after 250 [list ::tray::attach $parent]
}
proc ::tray::attach {parent} {
    if {![winfo exists $parent]} return
    if {[catch {::x11::tray_start [winfo id $parent]} err]} {
        puts stderr "TclPanel tray: $err"
        return
    }
    layout
}
proc ::tray::layout {} {catch {::x11::tray_layout}}
proc ::tray::stop {} {catch {::x11::tray_stop}}

proc ::tray::shutdown {} {stop}
