namespace eval ::panel {}
set ::panel::sourceDir [file dirname [file normalize [info script]]]
proc ::panel::loadConfig {} {
    set ::panel::root [file normalize [file join $::panel::sourceDir ..]]
    set home [expr {[info exists ::env(HOME)] ? $::env(HOME) : ""}]
    set userfile [file join $home .config tclpanel config.tcl]
    if {[file readable $userfile]} {source $userfile} else {source [file join $::panel::root config default.tcl]}
    foreach {key value} {position top height 38 monitor 0 refresh_ms 1500 show_taskbar 1 show_workspaces 1 show_clock 1 show_tray 1 modules {launcher appmenu taskbar workspace clock system_monitor power_menu tray} favorites {xterm firefox}} {
        if {![info exists ::cfg($key)]} {set ::cfg($key) $value}
    }
}
