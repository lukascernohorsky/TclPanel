namespace eval ::modules { variable loaded {}; variable directory {} }
proc ::modules::configure {dir} {variable directory; set directory $dir}
proc ::modules::load {name} {
    variable loaded; variable directory
    if {[dict exists $loaded $name]} {return 0}
    if {![regexp {^[A-Za-z0-9_]+$} $name]} {error "invalid module name: $name"}
    set path [file join $directory ${name}.tcl]
    if {![file readable $path]} {error "module not found: $name"}
    source $path
    dict set loaded $name $path
    if {[llength [info commands ::${name}::init]]} {::${name}::init}
    return 1
}
proc ::modules::unload {name} {
    variable loaded
    if {![dict exists $loaded $name]} {return 0}
    if {[llength [info commands ::${name}::shutdown]]} {catch {::${name}::shutdown}}
    dict unset loaded $name
    # Tcl procedures remain defined so already queued Tk callbacks cannot
    # become invalid commands. The module's timers/resources are stopped.
    return 1
}
proc ::modules::reload {name} {unload $name; return [load $name]}
proc ::modules::loaded {} {variable loaded; return [dict keys $loaded]}
