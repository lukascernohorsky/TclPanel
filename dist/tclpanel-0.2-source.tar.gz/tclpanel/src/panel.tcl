proc ::panel::selectedMonitor {} {
    set monitors {}
    if {[catch {set monitors [::x11::monitors]}] || ![llength $monitors]} {
        return [list screen-0 0 0 [winfo screenwidth .] [winfo screenheight .]]
    }
    set index $::cfg(monitor)
    if {![string is integer -strict $index] || $index < 0 || $index >= [llength $monitors]} {set index 0}
    return [lindex $monitors $index]
}
proc ::panel::build {} {
    lassign [selectedMonitor] monitorName mx my mw mh
    set h $::cfg(height)
    if {$::cfg(position) eq "bottom"} {set y [expr {$my+$mh-$h}]} else {set y $my}
    wm overrideredirect . 1
    catch {wm attributes . -type dock}
    wm geometry . ${mw}x${h}+$mx+$y
    . configure -background $::cfg(background)
    ttk::style theme use clam
    ttk::style configure TFrame -background $::cfg(background)
    ttk::style configure TLabel -background $::cfg(background) -foreground $::cfg(foreground) -padding 4
    ttk::style configure TButton -background #303744 -foreground $::cfg(foreground) -padding {7 3} -borderwidth 0
    ttk::style map TButton -background [list active $::cfg(accent)]
    ttk::frame .bar
    pack .bar -fill both -expand 1 -padx 4 -pady 2
    ttk::button .bar.menu -text "Applications" -command [list ::appmenu::popup .bar.menu]
    pack .bar.menu -side left -padx 2
    ttk::frame .bar.favs
    pack .bar.favs -side left -padx 3
    ::launcher::favorites .bar.favs
    ttk::frame .bar.tasks
    pack .bar.tasks -side left -fill both -expand 1 -padx 8
    if {$::cfg(show_workspaces)} {
        ttk::frame .bar.workspaces
        pack .bar.workspaces -side right -padx 3
        ::workspace::build .bar.workspaces
    }
    ttk::label .bar.monitor -text [::sysmon::sample]
    pack .bar.monitor -side right -padx 4
    if {$::cfg(show_clock)} {
        ttk::label .bar.clock -text ""
        pack .bar.clock -side right -padx 4
        ::clockmod::update .bar.clock
    }
    if {$::cfg(show_tray)} {
        ttk::frame .bar.tray -width 110 -height [expr {$h-8}]
        pack .bar.tray -side right -padx 3
        ::tray::start .bar.tray
    }
    ttk::button .bar.power -text "Power" -command [list ::power::popup .bar.power]
    pack .bar.power -side right -padx 2
    bind . <Escape> {exit}
    bind . <Destroy> {if {%W eq "."} {::tray::stop}}
    after 350 ::panel::setStrut
    after 500 ::panel::watchMonitors
    ::panel::refresh
}
proc ::panel::setStrut {} {
    if {![winfo exists .bar]} return
    update idletasks
    catch {::x11::strut [winfo id .] $::cfg(position)}
}
proc ::panel::watchMonitors {} {
    if {![winfo exists .]} return
    set current [selectedMonitor]
    lassign $current name x y w h
    set expectedY [expr {$::cfg(position) eq "bottom" ? $y+$h-$::cfg(height) : $y}]
    set expected "${w}x$::cfg(height)+$x+$expectedY"
    if {[wm geometry .] ne $expected} {wm geometry . $expected; after 250 ::panel::setStrut}
    after 5000 ::panel::watchMonitors
}
proc ::panel::refresh {} {
    if {![winfo exists .bar.tasks]} return
    if {$::cfg(show_taskbar)} {::taskbar::refresh .bar.tasks}
    .bar.monitor configure -text [::sysmon::sample]
    if {$::cfg(show_tray)} {::tray::layout}
    after $::cfg(refresh_ms) ::panel::refresh
}
