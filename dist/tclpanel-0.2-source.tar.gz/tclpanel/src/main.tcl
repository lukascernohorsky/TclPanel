#!/usr/bin/env wish
set here [file dirname [file normalize [info script]]]
source [file join $here config.tcl]
::panel::loadConfig
set ::panel::root [file normalize [file join $here ..]]
set candidates [list [file join $::panel::root lib tclpanelx11[info sharedlibextension]] [file normalize [file join $::panel::root .. .. lib tclpanel tclpanelx11[info sharedlibextension]]]]
set lib ""
foreach candidate $candidates {if {[file exists $candidate]} {set lib $candidate; break}}
if {$lib eq ""} {set lib [lindex $candidates 0]}
if {[catch {load $lib Tclpanelx11} err]} {
    tk_messageBox -icon error -title TclPanel -message "Cannot load TclPanel X11 extension:\n$err\n\nBuild it with 'make' from the project directory."
    exit 1
}
source [file join $here module_manager.tcl]
::modules::configure [file join $here modules]
foreach module $::cfg(modules) {
    if {[catch {::modules::load $module} err]} {puts stderr "TclPanel: cannot load module $module: $err"}
}
source [file join $::panel::root themes dark.tcl]
wm title . TclPanel
::panel::build
