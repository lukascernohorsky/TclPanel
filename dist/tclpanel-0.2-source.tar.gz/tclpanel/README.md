# TclPanel 0.2

A standalone, modular X11 desktop panel written in Tcl/Tk with a small Xlib extension. It has no XFCE, GTK, Qt, or libwnck dependency.

## Added in 0.2

- EWMH `_NET_WM_STRUT` and `_NET_WM_STRUT_PARTIAL` reservation.
- XRandR monitor enumeration when `libXrandr` development files are present; a single-screen fallback otherwise.
- Configurable monitor index and top/bottom placement.
- Initial XEmbed system tray manager using the freedesktop `_NET_SYSTEM_TRAY_Sn` selection and `_NET_SYSTEM_TRAY_OPCODE` docking message.
- Tcl module loader with load/unload/reload lifecycle hooks.
- Debian packaging metadata and a FreeBSD ports Makefile template.

## Requirements

- X11 and an EWMH-capable window manager.
- Tcl/Tk 8.6.
- C compiler, Tcl development headers and Xlib development headers.
- Optional but recommended: XRandR development library (`libxrandr-dev` on Debian; XRandR component in Xorg on FreeBSD).

Debian:

```sh
sudo apt install tcl tk tcl-dev tk-dev libx11-dev libxrandr-dev pkg-config build-essential
make
wish src/main.tcl
```

FreeBSD (package names can vary by repository/version):

```sh
pkg install tcl86 tk86 pkgconf xorg
make TCL_PKG=tcl86
wish src/main.tcl
```

If pkg-config does not expose Tcl as `tcl`, override `TCL_PKG`, for example `make TCL_PKG=tcl86`.

## Configuration

Copy `config/default.tcl` to `~/.config/tclpanel/config.tcl`. Configuration is Tcl code and must be trusted. Relevant options:

- `position`: `top` or `bottom`.
- `height`: panel height in pixels.
- `monitor`: zero-based XRandR monitor index (the first/primary monitor is normally index 0).
- `show_tray`: enable the XEmbed tray manager.
- `modules`: Tcl module names to source.

A module can define `::module_name::init` and `::module_name::shutdown` lifecycle procedures. The loader exposes `::modules::load`, `::modules::unload`, and `::modules::reload`.

## X11 extension API

- `::x11::windows` -> list of `{windowId title desktop}` rows.
- `::x11::activate windowId`
- `::x11::minimize windowId`
- `::x11::desktop`, `::x11::desktops`, `::x11::setdesktop index`
- `::x11::monitors` -> list of `{name x y width height}` rows.
- `::x11::strut panelWindowId top|bottom|left|right`
- `::x11::tray_start containerWindowId`, `::x11::tray_layout`, `::x11::tray_stop`.

## Important limitations

This is an initial implementation, not yet a replacement for every mature panel. The tray implementation supports the basic XEmbed docking path; it still needs interoperability testing with diverse tray clients, correct handling of `_XEMBED_INFO` mapped state, icon size hints, selection loss/reacquisition, and robust cleanup when clients disappear. It is a single tray per X screen. Multi-monitor selection uses XRandR monitor objects when available, but automatic per-monitor panel instances and hotplug-driven monitor reconfiguration are not implemented. EWMH struts are edge-based; a panel placed on a monitor that is not aligned with the virtual-screen edge can cause window managers to reserve more area than desired. Test with the target WM.

No runtime validation against a live X server or compilation against Tcl development headers was possible in the build environment used to prepare this source tree. Build and test on the target FreeBSD/Linux desktop before relying on it.

## Packaging

- Debian packaging metadata is in `debian/`; build with `dpkg-buildpackage -us -uc` on a Debian build host with the declared build dependencies.
- `freebsd/Makefile` is a ports Makefile template. Replace the placeholder maintainer address and integrate the source distfile/checksum into a local ports tree before submission.

## License

MIT. See `LICENSE`.
