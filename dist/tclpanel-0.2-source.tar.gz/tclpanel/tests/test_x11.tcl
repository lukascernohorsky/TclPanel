# Run from the project root after `make`, inside an X11 session.
set root [file normalize [file join [file dirname [info script]] ..]]
load [file join $root lib tclpanelx11[info sharedlibextension]] Tclpanelx11
puts "Desktop: [::x11::desktop]"
puts "Desktop count: [::x11::desktops]"
puts "Monitors: [::x11::monitors]"
puts "Windows: [::x11::windows]"
