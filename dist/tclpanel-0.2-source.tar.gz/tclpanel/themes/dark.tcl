set ::theme(background) #20242c
set ::theme(foreground) #e8edf5
set ::theme(button) #303744
set ::theme(active) #526b91
