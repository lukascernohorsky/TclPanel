set ::theme(background) #e9edf2
set ::theme(foreground) #20242c
set ::theme(button) #d5dce5
set ::theme(active) #9bb4d6
