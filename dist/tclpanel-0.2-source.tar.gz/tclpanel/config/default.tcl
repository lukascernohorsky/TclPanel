# TclPanel default configuration
set ::cfg(position) top             ;# top or bottom
set ::cfg(height) 38
set ::cfg(monitor) 0                ;# XRandR monitor index; 0 is primary/first
set ::cfg(background) #20242c
set ::cfg(foreground) #e8edf5
set ::cfg(accent) #526b91
set ::cfg(refresh_ms) 1500
set ::cfg(show_taskbar) 1
set ::cfg(show_workspaces) 1
set ::cfg(show_clock) 1
set ::cfg(show_tray) 1
set ::cfg(modules) {launcher appmenu taskbar workspace clock system_monitor power_menu tray}
set ::cfg(favorites) {xterm xterm firefox chromium thunar pcmanfm}
